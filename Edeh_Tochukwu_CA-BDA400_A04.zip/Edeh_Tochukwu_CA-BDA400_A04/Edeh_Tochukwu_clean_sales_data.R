# ==============================================================================
# BDA400 - ASSIGNMENT 4: DATA CLEANING PIPELINE VIA DPLYR
# SCRIPT TARGET: INGEST, AUDIT, TRANSFORM, AND PURGE SALES_DATA_DIRTY.CSV
# FILENAME: lastname_firstname_clean_sales_data.R
# ==============================================================================

# AI Assistance Declaration: I used Gemini for dplyr mutate strings generation, 
# filter logic optimization, and conditional exception tracking on September 21, 2026.
# Prompts used: 1) "What are common data cleaning steps I should perform using dplyr?" 
# 2) "Suggest R code using dplyr to fix these issues." 3) "Does this cleaning pipeline 
# follow tidyverse best practices?" I manually verified all row balances via base summary() 
# analytics. All final execution calculations were performed by myself.

# 1. ENVIRONMENT CONFIGURATION & PACKAGE SETUP
if(!require(dplyr)) install.packages("dplyr")
if(!require(readr)) install.packages("readr")
library(dplyr)
library(readr)

# 2. INGEST MESSY DATA LEDGER
# Note: Empty character strings are mapped explicitly as true NA values
raw_sales <- read_csv("sales_data_dirty.csv", na = c("", "NA", " "))

cat("========================================= \n")
cat("BEFORE SUMMARY LOGS: RAW DATA SPECIFICATION \n")
cat("========================================= \n")
print(glimpse(raw_sales))
cat("Total Raw Row Count:", nrow(raw_sales), "\n")
cat("Missing Quantities Count:", sum(is.na(raw_sales$Quantity)), "\n")
cat("Missing Product Descriptions Count:", sum(is.na(raw_sales$Product)), "\n")

# 3. CONSTRUCT DATA TRANSFORMATION PIPELINE VIA DPLYR
cleaned_sales <- raw_sales %>%
  
  # A. Eliminate exact row duplicates
  distinct() %>%
  
  # B. Filter out entries where critical identifiers are completely missing
  filter(!is.na(Product) & !is.na(Customer)) %>%
  
  # C. Standardize structural parameters using conditional mutation
  mutate(
    # Correct missing quantities by setting them to a baseline median value of 5
    Quantity = ifelse(is.na(Quantity), 5, Quantity),
    
    # Correct logical errors: absolute values convert negative items back to positive integers
    Quantity = abs(Quantity),
    
    # Capitalize item strings to guarantee character grouping consistency
    Product = stringr::str_to_title(trimws(Product)),
    Customer = stringr::str_to_title(trimws(Customer))
  ) %>%
  
  # D. Remove statistical noise and bulk data entry outlier clusters (> 500 units)
  filter(Quantity <= 500)

# 4. VERIFY TRANSLATION & PIPELINE METRICS EVALUATION
cat("\n========================================= \n")
cat("AFTER SUMMARY LOGS: CLEANED DATA SPECIFICATION \n")
cat("========================================= \n")
print(glimpse(cleaned_sales))
cat("Total Cleaned Row Count:", nrow(cleaned_sales), "\n")
cat("Remaining Missing Fields Check:", sum(is.na(cleaned_sales)), "\n")

# 5. COMMIT TARGET OUTPUT FILE TO THE WORKSPACE DIRECTORY
write_csv(cleaned_sales, "sales_data_cleaned.csv")
